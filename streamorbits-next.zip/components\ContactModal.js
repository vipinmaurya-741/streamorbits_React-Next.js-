'use client';
import { useState, useEffect } from 'react';

export default function ContactModal({ isOpen, onClose }) {
  const [form, setForm] = useState({ name: '', company: '', email: '', mobile: '', comment: '' });
  const [status, setStatus] = useState(''); // '', 'sending', 'error', 'success'
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { name, company, email, mobile } = form;
    if (!name || !company || !email || !mobile) {
      setStatus('error'); setErrorMsg('Please fill in all required fields.'); return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setStatus('error'); setErrorMsg('Please enter a valid email address.'); return;
    }
    setStatus('sending'); setErrorMsg('');

    // Save to localStorage
    const leads = JSON.parse(localStorage.getItem('so_leads') || '[]');
    leads.unshift({
      id: Date.now(),
      date: new Date().toLocaleString('en-IN'),
      name, company, email, mobile, comment: form.comment, status: 'New'
    });
    localStorage.setItem('so_leads', JSON.stringify(leads));

    // EmailJS (optional)
    try {
      const emailjs = window.emailjs;
      if (emailjs) {
        await emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', {
          from_name: name, company, from_email: email, phone: mobile, to_email: 'hello@streamorbits.com'
        });
      }
    } catch (err) {
      console.warn('EmailJS not configured:', err);
    }

    setStatus('success');
    setTimeout(() => {
      onClose();
      setTimeout(() => {
        setForm({ name: '', company: '', email: '', mobile: '', comment: '' });
        setStatus('');
        setErrorMsg('');
      }, 400);
    }, 2500);
  };

  return (
    <>
      <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js" />
      <div
        className={`modal-overlay${isOpen ? ' open' : ''}`}
        onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
        role="dialog"
        aria-modal="true"
        aria-label="Contact Form"
      >
        <div className="modal">
          <div className="modal__header">
            <div className="modal__header-label">Get In Touch</div>
            <div className="modal__header-title">Request a Custom Quote <span></span></div>
            <button className="modal__close" onClick={onClose} aria-label="Close">&#x2715;</button>
          </div>
          <div className="modal__body">
            {status === 'success' ? (
              <div className="modal__success show">
                <div className="modal__success-icon">
                  <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <h3>Thank You!</h3>
                <p>Your request has been received. Our production team will reach out within <strong>24 hours</strong> with a custom quote.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label" htmlFor="contactName">Full Name <span>*</span></label>
                    <input className="form-input" type="text" id="contactName" name="name" placeholder="John Smith" value={form.name} onChange={handleChange} required />
                  </div>
                  <div className="form-group">
                    <label className="form-label" htmlFor="contactCompany">Company Name <span>*</span></label>
                    <input className="form-input" type="text" id="contactCompany" name="company" placeholder="Acme Corp" value={form.company} onChange={handleChange} required />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="contactEmail">Email Address <span>*</span></label>
                  <input className="form-input" type="email" id="contactEmail" name="email" placeholder="john@company.com" value={form.email} onChange={handleChange} required />
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="contactMobile">Mobile Number <span>*</span></label>
                  <input className="form-input" type="tel" id="contactMobile" name="mobile" placeholder="+91 98765 43210" value={form.mobile} onChange={handleChange} required />
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="contactComment">Comment <span style={{color:'#aab0c0',fontWeight:'400'}}>(Optional)</span></label>
                  <textarea className="form-input" id="contactComment" name="comment" placeholder="Tell us about your event — date, audience size, platform preference…" rows="3" style={{resize:'vertical',minHeight:'80px'}} value={form.comment} onChange={handleChange}></textarea>
                </div>
                <button className="modal__submit" type="submit" disabled={status === 'sending'}>
                  {status === 'sending' ? 'Sending…' : 'Send Request'}
                  {status !== 'sending' && (
                    <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                  )}
                </button>
                {status === 'error' && <div className="form-status error">{errorMsg}</div>}
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
