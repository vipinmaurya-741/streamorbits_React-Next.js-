import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer__main">
        <div className="footer__brand">
          <a className="footer__logo" href="/" style={{marginBottom:'16px'}}>
            <svg viewBox="0 0 260 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{height:'48px',width:'auto'}}>
              <path d="M14 42 C24 8, 72 2, 92 14" stroke="#2BBCBE" strokeWidth="3" strokeLinecap="round" fill="none"/>
              <path d="M92 14 C112 28, 76 54, 44 58 C28 60, 14 52, 14 42" stroke="#2BBCBE" strokeWidth="3" strokeLinecap="round" fill="none"/>
              <path d="M17 24 C40 12, 72 11, 90 22" stroke="#2BBCBE" strokeWidth="1.6" strokeLinecap="round" fill="none" opacity="0.5"/>
              <circle cx="92" cy="12" r="3" fill="#2BBCBE"/>
              <circle cx="97" cy="7" r="1.9" fill="#2BBCBE" opacity="0.65"/>
              <circle cx="102" cy="3" r="1.2" fill="#2BBCBE" opacity="0.4"/>
              <circle cx="14" cy="44" r="3.6" fill="#2BBCBE"/>
              <circle cx="10" cy="51" r="2.2" fill="#2BBCBE" opacity="0.6"/>
              <circle cx="7" cy="57" r="1.3" fill="#2BBCBE" opacity="0.38"/>
              <text x="110" y="32" fontFamily="Barlow Condensed,Arial,sans-serif" fontSize="13" fontWeight="600" fill="rgba(255,255,255,0.7)" letterSpacing="1">stream</text>
              <text x="110" y="54" fontFamily="Barlow Condensed,Arial,sans-serif" fontSize="26" fontWeight="800" fill="#2BBCBE" letterSpacing="1.5">ORBITS</text>
            </svg>
          </a>
          <p className="footer__desc">
            streamOrbits is a professional virtual conferencing and live events agency, delivering broadcast-quality production experiences through advanced multi-camera setups and vMix technology — globally, reliably, beautifully.
          </p>
          <div className="footer__socials">
            <a href="https://www.linkedin.com/company/streamorbits" target="_blank" rel="noopener" aria-label="LinkedIn"><svg viewBox="0 0 24 24"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a href="https://www.facebook.com/streamorbits" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg></a>
            <a href="https://www.instagram.com/streamorbits" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
            <a href="https://www.twitter.com/streamorbits" target="_blank" rel="noopener" aria-label="Twitter"><svg viewBox="0 0 24 24"><path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"/></svg></a>
            <a href="https://www.youtube.com/@streamorbits" target="_blank" rel="noopener" aria-label="YouTube"><svg viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 00-1.95 1.96A29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 001.95-1.95A29 29 0 0023 12a29 29 0 00-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg></a>
          </div>
        </div>

        <div>
          <div className="footer__col-title">Services</div>
          <ul className="footer__links">
            <li><Link href="/services/virtual-set-events">Virtual Set Events</Link></li>
            <li><Link href="/services/hybrid-conference">Hybrid Conference Solutions</Link></li>
            <li><Link href="/services/multi-platform-streaming">Live Streaming &amp; Webcast</Link></li>
            <li><Link href="/services/vmix-switching">vMix Production &amp; Direction</Link></li>
            <li><Link href="/services/camera-studio-setup">Multi-Camera Studio Setup</Link></li>
            <li><Link href="/services/graphics-lower-thirds">Graphics &amp; Lower Thirds</Link></li>
            <li><Link href="/services/virtual-sets-backgrounds">Virtual Sets &amp; Backgrounds</Link></li>
          </ul>
        </div>

        <div>
          <div className="footer__col-title">Platform Support</div>
          <ul className="footer__links">
            <li><Link href="/services/zoom-events">Zoom Events</Link></li>
            <li><Link href="/services/microsoft-teams">Microsoft Teams</Link></li>
            <li><Link href="/services/cisco-webex">Cisco Webex</Link></li>
            <li><Link href="/services/google-meet-on24">Google Meet</Link></li>
            <li><Link href="/services/google-meet-on24">ON24 Webinars</Link></li>
            <li><a href="#">YouTube Live</a></li>
            <li><a href="#">Custom RTMP Platforms</a></li>
          </ul>
        </div>

        <div>
          <div className="footer__col-title">Contact</div>
          <div className="footer__contact-item">
            <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            <span>hello@streamorbit.com</span>
          </div>
          <div className="footer__contact-item">
            <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8a19.79 19.79 0 01-3.07-8.7A2 2 0 012 .18h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/></svg>
            <span>+1 (800) 555-0192</span>
          </div>
          <div className="footer__contact-item" style={{marginTop:'20px'}}>
            <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            <span>24/7 Live Event Support Available</span>
          </div>
        </div>
      </div>

      <div className="footer__bottom">
        <div className="footer__bottom-inner">
          <span>© 2025 streamOrbits. All rights reserved. Delivering broadcast-quality virtual events worldwide.</span>
          <div className="footer__bottom-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Cookie Policy</a>
            <a href="#">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
