'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useContactModal } from '../components/ContactModalContext';

const heroSlides = [
  { src: 'https://images.unsplash.com/photo-1601506521793-dc748fc80b67?w=900&q=80', alt: 'vMix Live Production', badge: 'LIVE PRODUCTION', title: 'vMix Pro — Live Switching', sub: 'Real-Time Scene Switching • Lower Thirds • Graphics' },
  { src: 'https://images.unsplash.com/photo-1598387993281-cecf8b71a8f8?w=900&q=80', alt: 'Broadcast Studio', badge: 'STUDIO', title: 'Broadcast Studio Setup', sub: 'Professional Camera • Lighting • Audio Rig' },
  { src: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=900&q=80', alt: 'Live Event', badge: 'LIVE EVENT', title: 'Annual General Meeting 2025', sub: 'streamOrbits vMix Pro • 4K Broadcast' },
  { src: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=900&q=80', alt: 'Multi Platform Streaming', badge: 'STREAMING', title: 'Multi-Platform Live Stream', sub: 'YouTube • LinkedIn • Facebook • Simultaneous' },
  { src: 'https://images.unsplash.com/photo-1591115765373-5207764f72e7?w=900&q=80', alt: 'Hybrid Conference', badge: 'HYBRID', title: 'Hybrid Conference Solution', sub: 'In-Person + Remote • Unified Experience' },
];

export default function HomePage() {
  const [activeSlide, setActiveSlide] = useState(0);
  const timerRef = useRef(null);
  const { open: openContact } = useContactModal();

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setActiveSlide(s => (s + 1) % heroSlides.length);
    }, 4000);
    return () => clearInterval(timerRef.current);
  }, []);

  // Reveal animation for cards
  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    document.querySelectorAll('.benefit-card, .trust-card, .manage-card, .usp-card').forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="hero__inner">
          <div className="hero__left">
            <div className="breadcrumb" style={{display:'flex',alignItems:'center',gap:'8px',fontSize:'0.78rem',color:'var(--grey-text)',marginBottom:'32px',fontFamily:'var(--font-light)'}}>
              <a href="#" style={{color:'var(--grey-text)',textDecoration:'none'}}>Home</a>
              <span style={{color:'var(--border)'}}>›</span>
              <Link href="/ai-summary" style={{background:'var(--red)',color:'#fff',padding:'3px 10px',borderRadius:'3px',fontWeight:'700',fontSize:'0.72rem',letterSpacing:'0.06em',textDecoration:'none'}}>AI Summary</Link>
            </div>
            <div className="hero__eyebrow">
              <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
              Live Production Excellence
            </div>
            <h1 className="hero__title">
              Professional Virtual Sets<br/>&amp; Live Production
            </h1>
            <div className="hero__title-accent"></div>
            <p className="hero__desc">
              Since the pandemic reshaped corporate communications, streamOrbits has been transforming plain online meetings into <strong>broadcast-quality live experiences</strong>. Our expert team deploys professional multi-camera feeds and custom <strong>vMix production layouts</strong> that integrate seamlessly within Zoom, MS Teams, Cisco Webex, and Google Meet — giving every corporate event the visual impact of a live television broadcast.
            </p>
            <div className="hero__actions">
              <button className="btn-primary" onClick={() => document.getElementById('ctaBand')?.scrollIntoView({behavior:'smooth'})}>
                Request a Demo
                <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
              </button>
              <a href="#usps" className="btn-outline">Explore Services</a>
            </div>
          </div>

          <div className="hero__image-panel" id="heroSlider">
            {heroSlides.map((slide, i) => (
              <div key={i} className={`hero__slide${activeSlide === i ? ' active' : ''}`}>
                <img src={slide.src} alt={slide.alt} />
                <div className="hero__overlay">
                  <div className="hero__overlay-badge"><span className="hero__live-dot"></span> {slide.badge}</div>
                  <div className="hero__overlay-title">{slide.title}</div>
                  <div className="hero__overlay-sub">{slide.sub}</div>
                </div>
              </div>
            ))}
            <div className="hero__dots">
              {heroSlides.map((_, i) => (
                <button key={i} className={`hero__dot${activeSlide === i ? ' active' : ''}`} onClick={() => { setActiveSlide(i); clearInterval(timerRef.current); }}></button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* WHAT WE OFFER */}
      <section className="section section--ice" id="usps">
        <div className="container">
          <div className="section-label">Our Core Services</div>
          <h2 className="section-title">What We Offer / Our USPs <span className="red-dash"></span></h2>
          <div className="usps__grid">
            <div className="usp-card">
              <div className="usp-card__icon-wrap">
                <svg viewBox="0 0 24 24"><path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
              </div>
              <div className="usp-card__title">Multi-Camera Production</div>
              <div className="usp-card__desc">Smooth scene transitions and cinema-grade multi-camera configurations. Our physical studio setups feature professional PTZ and broadcast cameras managed by experienced live directors — delivering seamless on-screen storytelling throughout your event.</div>
              <Link href="/services/camera-studio-setup" className="usp-card__link">
                Learn More
                <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
              </Link>
            </div>
            <div className="usp-card">
              <div className="usp-card__icon-wrap">
                <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              </div>
              <div className="usp-card__title">Advanced vMix Switching</div>
              <div className="usp-card__desc">Real-time background switching, custom lower thirds, branded virtual sets, and dynamic media overlays — all driven by our vMix technical directors. Instant scene changes keep your audience engaged with broadcast-quality pacing throughout the event.</div>
              <Link href="/services/vmix-switching" className="usp-card__link">
                Learn More
                <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
              </Link>
            </div>
            <div className="usp-card">
              <div className="usp-card__icon-wrap">
                <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8 8 0 000 11.4M17.7 6.3a8 8 0 010 11.4M3.5 3.5a13 13 0 000 17M20.5 3.5a13 13 0 010 17"/></svg>
              </div>
              <div className="usp-card__title">Broadcast-Quality Output</div>
              <div className="usp-card__desc">High-bitrate, low-latency streams featuring custom corporate graphics, branded lower thirds, and real-time media playback. Every stream is delivered at the visual standard your organization deserves, across any platform or destination.</div>
              <Link href="/services/webcast-production" className="usp-card__link">
                Learn More
                <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* STATS STRIP */}
      <div className="stats-strip">
        <div className="stats-strip__inner">
          <div className="stat-item"><div className="stat-item__num">11<span>+</span></div><div className="stat-item__label">Events Delivered</div></div>
          <div className="stat-item"><div className="stat-item__num">99<span>.9%</span></div><div className="stat-item__label">Uptime Reliability</div></div>
          <div className="stat-item"><div className="stat-item__num">1</div><div className="stat-item__label">Countries Served</div></div>
          <div className="stat-item"><div className="stat-item__num">1<span>+</span></div><div className="stat-item__label">Years of Experience</div></div>
        </div>
      </div>

      {/* BENEFITS */}
      <section className="section section--white">
        <div className="container">
          <div className="benefits__header">
            <div className="section-label" style={{justifyContent:'center'}}>Why Choose streamOrbits</div>
            <h2 className="section-title centered">Benefits <span className="red-dash"></span></h2>
          </div>
          <div className="benefits__grid">
            {[
              { icon: <svg viewBox="0 0 72 72"><rect x="8" y="10" width="56" height="42" rx="4" strokeWidth="2"/><path d="M8 20 Q20 32 8 44" strokeWidth="2"/><path d="M64 20 Q52 32 64 44" strokeWidth="2"/><line x1="20" y1="10" x2="20" y2="18" strokeWidth="2"/><line x1="52" y1="10" x2="52" y2="18" strokeWidth="2"/><rect x="24" y="52" width="24" height="6" rx="2" strokeWidth="1.6"/></svg>, text: 'Create visually striking experiences that capture and maintain audience attention.' },
              { icon: <svg viewBox="0 0 72 72"><path d="M36 8 L58 18 L58 38 C58 52 36 64 36 64 C36 64 14 52 14 38 L14 18 Z" strokeWidth="2"/><path d="M26 36 L33 43 L48 28" strokeWidth="2.5"/></svg>, text: 'Reinforce brand presence throughout every moment of the live event.' },
              { icon: <svg viewBox="0 0 72 72"><rect x="10" y="14" width="52" height="34" rx="4" strokeWidth="2"/><line x1="24" y1="48" x2="20" y2="58" strokeWidth="2"/><line x1="48" y1="48" x2="52" y2="58" strokeWidth="2"/><line x1="18" y1="58" x2="54" y2="58" strokeWidth="2"/><circle cx="36" cy="31" r="8" strokeWidth="1.8"/><circle cx="36" cy="31" r="3" strokeWidth="1.8"/></svg>, text: 'Convert plain webinars into immersive, interactive viewer experience events.' },
              { icon: <svg viewBox="0 0 72 72"><circle cx="36" cy="32" r="20" strokeWidth="2"/><path d="M36 18 L36 46M30 24 Q30 20 36 20 Q42 20 42 26 Q42 32 36 32 Q30 32 30 38 Q30 44 36 44 Q42 44 42 40" strokeWidth="2"/><line x1="20" y1="58" x2="52" y2="58" strokeWidth="2" strokeDasharray="4 3"/></svg>, text: 'Reduce physical set build and logistics costs dramatically versus in-person productions.' },
              { icon: <svg viewBox="0 0 72 72"><rect x="12" y="12" width="20" height="20" rx="3" strokeWidth="2"/><rect x="40" y="12" width="20" height="20" rx="3" strokeWidth="2"/><rect x="12" y="40" width="20" height="20" rx="3" strokeWidth="2"/><rect x="40" y="40" width="20" height="20" rx="3" strokeWidth="2"/><path d="M32 22 L40 22M22 32 L22 40M50 32 L50 40M32 50 L40 50" strokeWidth="2"/></svg>, text: 'Adapt quickly to different corporate event types with fully flexible production designs.' },
              { icon: <svg viewBox="0 0 72 72"><circle cx="36" cy="36" r="22" strokeWidth="2"/><ellipse cx="36" cy="36" rx="10" ry="22" strokeWidth="1.8"/><line x1="14" y1="28" x2="58" y2="28" strokeWidth="1.8"/><line x1="14" y1="44" x2="58" y2="44" strokeWidth="1.8"/></svg>, text: 'Deliver a professional live broadcast, TV-studio experience to global audiences anywhere.' },
            ].map((b, i) => (
              <div key={i} className="benefit-card">
                <div className="benefit-card__icon">{b.icon}</div>
                <div className="benefit-card__text">{b.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY TRUST US */}
      <section className="section section--ice">
        <div className="container">
          <div className="trust__header">
            <div className="section-label">Our Track Record</div>
            <h2 className="section-title">Why Organizations Trust streamOrbits <span className="red-dash"></span></h2>
          </div>
          <div className="trust__grid-top">
            <div className="trust-card">
              <div className="trust-card__icon"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg></div>
              <div className="trust-card__title">Enterprise-Grade Video Conferencing</div>
              <div className="trust-card__desc">Deep expertise with Cisco, Polycom, and enterprise hardware VC bridges — ensuring seamless integration with your existing infrastructure.</div>
            </div>
            <div className="trust-card">
              <div className="trust-card__icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2"/><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="12" fill="none"/><line x1="2" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22" y2="12"/></svg></div>
              <div className="trust-card__title">Multi-Location Connectivity</div>
              <div className="trust-card__desc">Seamless integration of remote speakers and audiences across continents, bridging on-site and remote participants into a single cohesive live experience.</div>
            </div>
            <div className="trust-card">
              <div className="trust-card__icon"><svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div>
              <div className="trust-card__title">Proven Hybrid Track Record</div>
              <div className="trust-card__desc">Flawless execution of complex internal corporate communications — from board meetings and AGMs to multi-day leadership summits with thousands of attendees.</div>
            </div>
          </div>
          <div className="trust__grid-bottom">
            <div className="trust-card">
              <div className="trust-card__icon"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></div>
              <div className="trust-card__title">On-Site &amp; Remote Engineering</div>
              <div className="trust-card__desc">Dedicated live vMix technical directors and professional camera operators available both on-site and remotely — providing expert support throughout every event.</div>
            </div>
            <div className="trust-card">
              <div className="trust-card__icon"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
              <div className="trust-card__title">Redundant Systems &amp; Backups</div>
              <div className="trust-card__desc">Dual-ISP failover connections, backup power systems, and redundant encoding hardware — designed to ensure absolute zero downtime throughout your critical live event.</div>
            </div>
          </div>
        </div>
      </section>

      {/* PLATFORM SUPPORT */}
      <section className="section section--white" id="platforms">
        <div className="container">
          <div className="platform__title">
            <div className="section-label" style={{justifyContent:'center'}}>Integrations</div>
            <h2 className="section-title centered">Platform Support <span className="red-dash"></span></h2>
          </div>
          <div className="platform__logos">
            <div className="platform-logo">
              <div className="platform-logo__icon">
                <svg viewBox="0 0 80 36" fill="none"><rect width="80" height="36" rx="6" fill="#2D8CFF"/><text x="10" y="26" fontFamily="Arial,sans-serif" fontSize="18" fontWeight="700" fill="white">zoom</text></svg>
              </div>
              <div className="platform-logo__name">Zoom</div>
            </div>
            <div className="platform-logo">
              <div className="platform-logo__icon">
                <svg viewBox="0 0 40 36" fill="none"><rect width="40" height="36" rx="6" fill="#464EB8"/><rect x="8" y="10" width="16" height="16" rx="3" fill="white" fillOpacity="0.9"/><rect x="20" y="6" width="12" height="12" rx="2" fill="white" fillOpacity="0.7"/></svg>
              </div>
              <div className="platform-logo__name">Microsoft Teams</div>
            </div>
            <div className="platform-logo">
              <div className="platform-logo__icon">
                <svg viewBox="0 0 120 36" fill="none" height="36">
                  <circle cx="18" cy="18" r="14" fill="#00BCF2"/>
                  <path d="M10 13 L14 23 L18 16 L22 23 L26 13" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
                  <text x="38" y="24" fontFamily="Arial,sans-serif" fontSize="15" fontWeight="700" fill="#00BCF2" letterSpacing="-0.3">webex</text>
                </svg>
              </div>
              <div className="platform-logo__name">Cisco Webex</div>
            </div>
            <div className="platform-logo">
              <div className="platform-logo__icon">
                <svg viewBox="0 0 50 36" fill="none"><rect width="50" height="36" rx="6" fill="#F6F6F6" stroke="#E0E0E0"/><rect x="8" y="10" width="20" height="16" rx="3" fill="#1A73E8"/><path d="M30 14 L42 10 L42 26 L30 22 Z" fill="#34A853"/></svg>
              </div>
              <div className="platform-logo__name">Google Meet</div>
            </div>
            <div className="platform-logo">
              <div className="platform-logo__icon">
                <svg viewBox="0 0 60 36" fill="none"><rect width="60" height="36" rx="6" fill="#002855"/><text x="8" y="25" fontFamily="Arial,sans-serif" fontSize="15" fontWeight="800" fill="white">ON24</text></svg>
              </div>
              <div className="platform-logo__name">ON24</div>
            </div>
            <div className="platform-logo">
              <div className="platform-logo__icon">
                <svg viewBox="0 0 50 36" fill="none"><rect width="50" height="36" rx="6" fill="#EEF2F8" stroke="#D6DCE8"/><circle cx="25" cy="18" r="8" stroke="#5A6478" strokeWidth="1.5" fill="none"/><line x1="25" y1="10" x2="25" y2="26" stroke="#5A6478" strokeWidth="1.5"/><line x1="17" y1="18" x2="33" y2="18" stroke="#5A6478" strokeWidth="1.5"/></svg>
              </div>
              <div className="platform-logo__name">Other Platforms</div>
            </div>
          </div>

          <div className="manage__header">
            <div className="section-label">Operational Workflow</div>
            <h3 className="section-title">What We Manage <span className="red-dash"></span></h3>
          </div>
          <div className="manage__grid">
            {[
              { num: '01', title: 'Speaker Onboarding & Briefing', desc: 'Comprehensive tech checks, remote speaker briefings, camera positioning guidance, and pre-event run-throughs to guarantee a flawless live performance.', icon: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>' },
              { num: '02', title: 'Registration & Event Access Setup', desc: 'Secure event registration configuration, branded access portals, and participant credential management for seamless attendee entry to your event.', icon: '<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/>' },
              { num: '03', title: 'Waiting Room Hosting & Session Control', desc: 'Professional waiting room hosting, live speaker switching, session flow management, and real-time production direction throughout the entire broadcast.', icon: '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>' },
              { num: '04', title: 'Live Q&A, Polling & Engagement', desc: 'Active moderation of live Q&A sessions, audience polling deployment, and interactive engagement features to maximize participation and event value.', icon: '<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>' },
            ].map((card, i) => (
              <div key={i} className="manage-card">
                <div className="manage-card__num">{card.num}</div>
                <div className="manage-card__icon">
                  <svg viewBox="0 0 24 24" dangerouslySetInnerHTML={{__html: card.icon}}/>
                </div>
                <div className="manage-card__title" dangerouslySetInnerHTML={{__html: card.title}}/>
                <div className="manage-card__desc">{card.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA BAND */}
      <div className="cta-band" id="ctaBand">
        <div className="container">
          <h2 className="cta-band__title">Ready to Elevate Your Next Corporate Event?</h2>
          <p className="cta-band__sub">Talk to our production team and get a custom quote within 24 hours.</p>
          <button className="btn-white" onClick={openContact}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            Contact Our Team
          </button>
        </div>
      </div>
    </>
  );
}
