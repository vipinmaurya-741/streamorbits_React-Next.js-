import Link from 'next/link';

export default function AboutPage() {
  return (
    <>
      <div className="about-hero">
        <div className="about-hero__eyebrow">Who We Are</div>
        <h1 className="about-hero__title">stream<span>ORBITS</span></h1>
        <p className="about-hero__sub">A premium Virtual Conferencing & Live Events Agency delivering broadcast-quality productions for the world's leading organisations — powered by vMix, professional cameras, and a passionate team of live event specialists.</p>
        <Link href="/" className="about-back">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
          Back to Home
        </Link>
      </div>

      <section className="about-story">
        <div className="about-story__inner">
          <div className="about-story__img">
            <img src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80" alt="streamOrbits Live Event"/>
          </div>
          <div className="about-story__text">
            <div className="section-label">Our Story</div>
            <h2>Built for the New Era of Live Events</h2>
            <p>streamOrbits was founded with a single conviction — that virtual and hybrid events deserve the same production quality as the world's greatest live broadcasts. We saw organisations settling for plain Zoom calls when they deserved a full broadcast studio experience.</p>
            <p>Today we deliver <strong>AGMs, Town Halls, Corporate Webinars, Hybrid Conferences, and Product Launches</strong> with professional camera setups, vMix production switching, broadcast-grade graphics, and flawless multi-platform streaming — all managed by our in-house expert team.</p>
            <p>From a single boardroom to a 10,000-attendee global event, streamOrbits brings the same obsessive attention to production quality to every engagement.</p>
          </div>
        </div>
      </section>

      <section className="about-values">
        <div className="about-values__inner">
          <div className="about-values__header">
            <div className="section-label" style={{justifyContent:'center'}}>What Drives Us</div>
            <h2 className="section-title centered">Our Core Values <span className="red-dash"></span></h2>
          </div>
          <div className="about-values__grid">
            {[
              { icon: '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>', title: 'Broadcast Quality, Always', desc: 'Every event we produce is held to broadcast television standards. We do not cut corners — from pre-production planning to the final frame of your event.' },
              { icon: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>', title: 'Client-First Partnership', desc: 'We become an extension of your team — understanding your brand, your audience, and your goals to deliver an event that exceeds expectations every time.' },
              { icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>', title: 'Zero-Failure Reliability', desc: 'With 99.9% uptime across all our productions, our redundancy systems, backup infrastructure, and experienced operators ensure your event never stops.' },
              { icon: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 010 20M12 2a15.3 15.3 0 000 20"/>', title: 'Global Reach, Local Expertise', desc: 'Whether your audience is in one city or spread across 40 countries, our CDN infrastructure and multi-location bridging expertise ensures everyone gets the same flawless experience.' },
              { icon: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>', title: 'Innovation-Led Production', desc: 'We stay ahead — virtual sets, AI backgrounds, real-time graphics, multi-platform simultaneous streaming. We bring the latest broadcast technology to every event.' },
              { icon: '<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>', title: 'Passion for Live Events', desc: 'Live events are our passion, not just our business. Every countdown, every cue, every moment — we treat your event with the care and excitement it deserves.' },
            ].map((val, i) => (
              <div key={i} className="about-val-card">
                <div className="about-val-card__icon">
                  <svg viewBox="0 0 24 24" dangerouslySetInnerHTML={{__html: val.icon}}/>
                </div>
                <div className="about-val-card__title">{val.title}</div>
                <div className="about-val-card__desc">{val.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="about-team">
        <div className="about-team__inner">
          <div className="about-team__header">
            <div className="section-label" style={{justifyContent:'center'}}>The People Behind streamOrbits</div>
            <h2 className="section-title centered">Meet Our Team <span className="red-dash"></span></h2>
          </div>
          <div className="about-team__grid">
            {[
              { initials: 'NS', name: 'Nirmal Singh', role: 'Founder & Executive Producer' },
              { initials: 'VM', name: 'Vipin Maurya', role: 'Head of vMix Production' },
              { initials: 'AS', name: 'Anmol Singh', role: 'Client Success Manager' },
            ].map((member, i) => (
              <div key={i} className="team-card">
                <div className="team-card__avatar">{member.initials}</div>
                <div className="team-card__name">{member.name}</div>
                <div className="team-card__role">{member.role}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
