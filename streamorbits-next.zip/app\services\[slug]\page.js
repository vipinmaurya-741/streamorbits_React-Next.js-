'use client';
import { useState } from 'react';
import { notFound } from 'next/navigation';
import serviceData from '../../../data/serviceData';
import ServicePage from '../../../components/ServicePage';
import ContactModal from '../../../components/ContactModal';

export default function ServicePageRoute({ params }) {
  const { slug } = params;
  const data = serviceData[slug];
  const [contactOpen, setContactOpen] = useState(false);

  if (!data) {
    notFound();
  }

  return (
    <>
      <ServicePage data={data} onOpenContact={() => setContactOpen(true)} />
      <ContactModal isOpen={contactOpen} onClose={() => setContactOpen(false)} />
    </>
  );
}
