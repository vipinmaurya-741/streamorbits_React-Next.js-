import Link from 'next/link';

export default function AiSummaryPage() {
  return (
    <>
      <div className="ai-hero">
        <div className="ai-hero__badge">
          <svg viewBox="0 0 24 24"><path d="M12 2a2 2 0 012 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 017 7h1a1 1 0 010 2h-1v1a2 2 0 01-2 2H5a2 2 0 01-2-2v-1H2a1 1 0 010-2h1a7 7 0 017-7h1V5.73A2 2 0 0110 4a2 2 0 012-2z"/></svg>
          Artificial Intelligence in Live Events
        </div>
        <h1 className="ai-hero__title">How <span>AI</span> is Transforming<br/>the Events Industry</h1>
        <p className="ai-hero__sub">From intelligent production automation to real-time audience analytics, Artificial Intelligence is reshaping how live events are planned, produced, and experienced — and streamOrbits is at the forefront of this revolution.</p>
        <Link href="/" className="about-back">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
          Back to Home
        </Link>
      </div>

      <section className="ai-section ai-section--white">
        <div className="ai-section__inner">
          <div className="ai-intro-grid">
            <div className="ai-intro__img">
              <img src="https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=800&q=80" alt="AI in Events"/>
            </div>
            <div className="ai-intro__text">
              <div className="section-label">The AI Revolution</div>
              <h2>Events Are Getting Smarter</h2>
              <p>The live events industry is undergoing its biggest transformation since the internet. Artificial Intelligence is no longer a futuristic concept — it is actively being deployed in production control rooms, audience engagement tools, content delivery systems, and post-event analytics platforms right now.</p>
              <p>At streamOrbits, we integrate AI-powered tools across our production workflow — from <strong>automated scene switching assistance</strong> and <strong>AI background removal for virtual sets</strong> to <strong>real-time caption generation</strong> and <strong>intelligent stream quality monitoring</strong> — ensuring every event we produce is sharper, smarter, and more reliable than ever before.</p>
              <p>Understanding how AI is reshaping the industry helps our clients make better decisions about their event strategy, technology investment, and audience engagement approach.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="ai-section ai-section--ice">
        <div className="ai-section__inner">
          <div className="ai-section__header">
            <div className="section-label" style={{justifyContent:'center'}}>Key Impact Areas</div>
            <h2 className="section-title centered">6 Ways AI is Changing Live Events <span className="red-dash"></span></h2>
          </div>
          <div className="ai-cards">
            {[
              { icon: '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>', title: 'AI-Powered Virtual Sets', desc: 'AI background removal and real-time 3D virtual set rendering replace physical studios. Speakers can present from any location while appearing in a world-class broadcast environment — no green screen required.' },
              { icon: '<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>', title: 'Real-Time Captions & Translation', desc: 'AI transcription engines generate live captions with 95%+ accuracy across 50+ languages. Global audiences receive real-time translated subtitles, dramatically expanding event reach and accessibility.' },
              { icon: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>', title: 'Intelligent Stream Monitoring', desc: 'AI algorithms continuously monitor stream quality, bitrate, and latency in real time — automatically adjusting encoding parameters and triggering failover systems before a viewer experiences any disruption.' },
              { icon: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>', title: 'Audience Engagement Analytics', desc: 'AI analyses viewer attention patterns, drop-off points, poll responses, and Q&A sentiment in real time — giving event producers actionable insights to adjust content pacing and maximise engagement during the event.' },
              { icon: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>', title: 'Automated Graphics & Lower Thirds', desc: 'AI-assisted production tools automatically detect speaker changes and trigger the correct lower third graphics, name cards, and title animations — reducing manual operator workload and eliminating on-screen errors.' },
              { icon: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>', title: 'Post-Event Content Intelligence', desc: 'AI automatically chapters, transcribes, and tags recorded event content — creating searchable VOD libraries, highlight reels, and social media clips from a single recording within minutes of the event ending.' },
            ].map((card, i) => (
              <div key={i} className="ai-card">
                <div className="ai-card__icon">
                  <svg viewBox="0 0 24 24" dangerouslySetInnerHTML={{__html: card.icon}}/>
                </div>
                <div className="ai-card__title">{card.title}</div>
                <div className="ai-card__desc">{card.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="ai-section ai-section--white">
        <div className="ai-section__inner">
          <div className="ai-section__header">
            <div className="section-label" style={{justifyContent:'center'}}>Our AI Workflow</div>
            <h2 className="section-title centered">How streamOrbits Uses AI <span className="red-dash"></span></h2>
          </div>
          <div className="ai-timeline">
            {[
              { title: 'Pre-Event AI Planning', desc: 'Before your event begins, AI tools help us optimise run-of-show timings, simulate audience load on streaming infrastructure, and auto-generate production scripts from your briefing documents — cutting pre-production time by up to 20%.' },
              { title: 'Live AI Background Removal', desc: 'Our vMix pipeline integrates AI-powered background removal for remote speakers — no physical green screen needed. Speakers are cleanly composited into virtual sets in real time, even with complex hair and movement.' },
              { title: 'Real-Time Caption Engine', desc: 'Our live events include AI-generated captions powered by speech recognition APIs with custom vocabulary training for your industry terminology — ensuring accurate, professional subtitles throughout your broadcast.' },
              { title: 'AI Stream Health Monitoring', desc: 'Throughout every production, our AI monitoring stack watches stream health parameters simultaneously — automatically alerting our technical team and activating backup systems if any metric falls outside acceptable thresholds.' },
              { title: 'Post-Event AI Editing', desc: 'After your event, AI tools automatically generate a structured VOD with chapters, searchable transcript, speaker-tagged highlights, and social media clips — delivered to you shortly after your event concludes.' },
            ].map((step, i) => (
              <div key={i} className="ai-step">
                <div className="ai-step__num">{i + 1}</div>
                <div className="ai-step__body">
                  <div className="ai-step__title">{step.title}</div>
                  <div className="ai-step__desc">{step.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{background:'var(--blue-deep)',padding:'56px 2rem'}}>
        <div style={{maxWidth:'1000px',margin:'0 auto',display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'24px',textAlign:'center'}}>
          {[
            { val: 'High Accuracy', label: 'AI Caption Quality' },
            { val: 'Faster Workflow', label: 'Pre-Production Efficiency' },
            { val: 'Multi-Language', label: 'Global Audience Support' },
            { val: 'Quick Delivery', label: 'Post-Event VOD Turnaround' },
          ].map((s, i) => (
            <div key={i}>
              <div style={{fontFamily:'var(--font-head)',fontSize:'1.1rem',fontWeight:'800',color:'var(--teal)',marginBottom:'6px'}}>{s.val}</div>
              <div style={{fontSize:'0.8rem',color:'rgba(255,255,255,0.6)',fontWeight:'500'}}>{s.label}</div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
