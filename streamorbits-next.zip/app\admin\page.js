'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

function esc(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

export default function AdminPage() {
  const [leads, setLeads] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    loadLeads();
  }, []);

  function loadLeads() {
    const data = JSON.parse(localStorage.getItem('so_leads') || '[]');
    setLeads(data);
  }

  function changeStatus(id, status) {
    const updated = leads.map(l => l.id === id ? { ...l, status } : l);
    setLeads(updated);
    localStorage.setItem('so_leads', JSON.stringify(updated));
  }

  function deleteLead(id) {
    if (!confirm('Delete this lead?')) return;
    const updated = leads.filter(l => l.id !== id);
    setLeads(updated);
    localStorage.setItem('so_leads', JSON.stringify(updated));
  }

  function clearAll() {
    if (!confirm('Delete ALL leads? This cannot be undone.')) return;
    localStorage.removeItem('so_leads');
    setLeads([]);
  }

  function exportCSV() {
    if (!leads.length) { alert('No data to export.'); return; }
    const headers = ['#', 'Name', 'Company', 'Email', 'Mobile', 'Date', 'Comment', 'Status'];
    const rows = leads.map((l, i) =>
      [leads.length - i, l.name, l.company, l.email, l.mobile, l.date, l.comment || '', l.status]
        .map(v => `"${String(v || '').replace(/"/g, '""')}"`).join(',')
    );
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `streamorbits-leads-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  }

  const filtered = search
    ? leads.filter(l =>
        (l.name || '').toLowerCase().includes(search.toLowerCase()) ||
        (l.company || '').toLowerCase().includes(search.toLowerCase()) ||
        (l.email || '').toLowerCase().includes(search.toLowerCase()) ||
        (l.mobile || '').toLowerCase().includes(search.toLowerCase())
      )
    : leads;

  const statNew = leads.filter(l => l.status === 'New').length;
  const statContacted = leads.filter(l => l.status === 'Contacted').length;
  const statClosed = leads.filter(l => l.status === 'Closed').length;

  return (
    <div style={{ fontFamily: "'Barlow', sans-serif", background: '#EEF2F9', minHeight: '100vh' }}>
      {/* HEADER */}
      <header style={{ background: '#061535', padding: '0 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px', borderBottom: '3px solid #2BBCBE' }}>
        <div>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.4rem', fontWeight: 800, color: '#fff', letterSpacing: '0.04em' }}>
            stream<span style={{ color: '#2BBCBE' }}>ORBITS</span>
          </div>
          <div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.45)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: '2px' }}>Admin Panel — Lead Management</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ background: '#E0201A', color: '#fff', fontSize: '0.62rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '4px 10px', borderRadius: '3px', display: 'flex', alignItems: 'center', gap: '5px' }}>
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#fff', animation: 'pulse 1.4s infinite', display: 'inline-block' }}></span>
            Live Data
          </div>
          <Link href="/" style={{ background: 'transparent', border: '1.5px solid rgba(255,255,255,0.25)', color: 'rgba(255,255,255,0.8)', fontFamily: "'Barlow', sans-serif", fontSize: '0.8rem', padding: '6px 14px', borderRadius: '6px', cursor: 'pointer', textDecoration: 'none', transition: 'border-color .2s,color .2s' }}>
            ← Back to Website
          </Link>
        </div>
      </header>

      <main style={{ maxWidth: '1320px', margin: '0 auto', padding: '32px 24px' }}>
        {/* STATS */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '16px', marginBottom: '32px' }}>
          {[
            { val: leads.length, label: 'Total Leads', color: 'rgba(43,188,190,0.12)', stroke: '#2BBCBE', icon: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>' },
            { val: statNew, label: 'New (Unread)', color: 'rgba(224,32,26,0.1)', stroke: '#E0201A', icon: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>' },
            { val: statContacted, label: 'Contacted', color: 'rgba(6,21,53,0.08)', stroke: '#0E2D6B', icon: '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>' },
            { val: statClosed, label: 'Closed / Won', color: 'rgba(34,197,94,0.1)', stroke: '#16a34a', icon: '<polyline points="20 6 9 17 4 12"/>' },
          ].map((stat, i) => (
            <div key={i} style={{ background: '#fff', borderRadius: '12px', padding: '22px 24px', border: '1px solid #D8E3F2', boxShadow: '0 2px 8px rgba(6,21,53,0.06)', display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '10px', background: stat.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke={stat.stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" dangerouslySetInnerHTML={{ __html: stat.icon }} />
              </div>
              <div>
                <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '2rem', fontWeight: 800, lineHeight: 1, color: '#061535' }}>{stat.val}</div>
                <div style={{ fontSize: '0.75rem', color: '#6B7A99', marginTop: '4px', fontWeight: 500, letterSpacing: '0.04em' }}>{stat.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* TOOLBAR */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.3rem', fontWeight: 800, color: '#061535' }}>All Leads</div>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <input
              type="text"
              placeholder="Search name, company, email…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ border: '1.5px solid #D8E3F2', borderRadius: '8px', padding: '8px 14px', fontFamily: "'Barlow', sans-serif", fontSize: '0.85rem', color: '#061535', outline: 'none', width: '220px' }}
            />
            <button onClick={exportCSV} style={{ background: '#2BBCBE', color: '#fff', border: 'none', borderRadius: '8px', padding: '9px 18px', fontFamily: "'Barlow', sans-serif", fontSize: '0.83rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Export CSV
            </button>
            <button onClick={clearAll} style={{ background: 'transparent', color: '#E0201A', border: '1.5px solid #E0201A', borderRadius: '8px', padding: '9px 16px', fontFamily: "'Barlow', sans-serif", fontSize: '0.83rem', fontWeight: 600, cursor: 'pointer' }}>
              Clear All
            </button>
          </div>
        </div>

        {/* TABLE */}
        <div style={{ background: '#fff', borderRadius: '14px', border: '1px solid #D8E3F2', boxShadow: '0 4px 16px rgba(6,21,53,0.07)', overflow: 'hidden' }}>
          {filtered.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '72px 24px' }}>
              <div style={{ fontSize: '3.5rem', marginBottom: '16px', opacity: 0.4 }}>📋</div>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.4rem', fontWeight: 800, color: '#061535', marginBottom: '8px' }}>No leads yet</div>
              <div style={{ fontSize: '0.9rem', color: '#6B7A99' }}>When someone fills the contact form on your website, their details will appear here.</div>
            </div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead style={{ background: '#061535' }}>
                <tr>
                  {['#', 'Name', 'Company', 'Email', 'Mobile', 'Date & Time', 'Comment', 'Status', ''].map((h, i) => (
                    <th key={i} style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.65)', padding: '14px 18px', textAlign: 'left' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((l, i) => (
                  <tr key={l.id} style={{ borderBottom: '1px solid #D8E3F2' }}>
                    <td style={{ padding: '14px 18px', fontSize: '0.72rem', color: '#6B7A99', fontWeight: 500 }}>{filtered.length - i}</td>
                    <td style={{ padding: '14px 18px', fontSize: '0.87rem', color: '#061535', fontWeight: 600 }}>{l.name}</td>
                    <td style={{ padding: '14px 18px', fontSize: '0.87rem', color: '#0E2D6B', fontWeight: 500 }}>{l.company}</td>
                    <td style={{ padding: '14px 18px', fontSize: '0.87rem' }}><a href={`mailto:${l.email}`} style={{ color: '#2BBCBE', textDecoration: 'none' }}>{l.email}</a></td>
                    <td style={{ padding: '14px 18px', fontSize: '0.83rem', fontFamily: 'monospace' }}>{l.mobile}</td>
                    <td style={{ padding: '14px 18px', fontSize: '0.78rem', color: '#6B7A99' }}>{l.date}</td>
                    <td style={{ padding: '14px 18px', maxWidth: '200px', fontSize: '0.82rem', color: '#6B7A99', fontStyle: l.comment ? 'normal' : 'italic' }}>{l.comment || '—'}</td>
                    <td style={{ padding: '14px 18px' }}>
                      <select
                        value={l.status}
                        onChange={e => changeStatus(l.id, e.target.value)}
                        style={{ border: '1.5px solid #D8E3F2', borderRadius: '6px', padding: '4px 8px', fontFamily: "'Barlow', sans-serif", fontSize: '0.78rem', color: '#061535', cursor: 'pointer', outline: 'none', background: '#fff' }}
                      >
                        <option>New</option>
                        <option>Contacted</option>
                        <option>Closed</option>
                      </select>
                    </td>
                    <td style={{ padding: '14px 18px' }}>
                      <button onClick={() => deleteLead(l.id)} title="Delete" style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#cbd5e1', padding: '4px' }}>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>

      <footer style={{ textAlign: 'center', padding: '24px', fontSize: '0.75rem', color: '#6B7A99', borderTop: '1px solid #D8E3F2', marginTop: '40px' }}>
        streamOrbits Admin Panel &nbsp;·&nbsp; Data stored locally in browser &nbsp;·&nbsp; © 2025
      </footer>
    </div>
  );
}
