const serviceData = {
  'virtual-set-events': {
    category: 'Virtual & Hybrid Events', eyebrow: 'Custom Video Layouts',
    title: 'Virtual Set Events',
    desc: `A Virtual Set is a custom video layout integrated instead of the standard layouts available in online meeting platforms like <strong>Zoom, MS Teams, Cisco Webex</strong>, and Google Meet. Using virtual set integration gives your organisation the flexibility to have fully branded custom backgrounds, dynamic camera positions, and immersive visual environments — elevating any online meeting into a professional broadcast event.`,
    visualLabel: 'VIRTUAL SET INTEGRATION', visualSub: 'Custom Layout • Live Broadcast',
    image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=900&q=80',
    iconPath: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
    features: [
      { title: 'Custom Layout Design', desc: 'Replace the default tiled grid of online platforms with a fully branded layout — showing your logo, sponsor banners, and speaker frames in precisely designed positions.', icon: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>' },
      { title: 'Platform Integration', desc: 'Our virtual sets integrate seamlessly with Zoom, MS Teams, Cisco Webex, and Google Meet without requiring any additional software installation for your speakers or attendees.', icon: '<circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8 8 0 000 11.4M17.7 6.3a8 8 0 010 11.4"/>' },
      { title: 'Real-Time Switching', desc: 'Our vMix operators switch between multiple virtual set scenes in real time — transitioning from plenary sessions to panel discussions to breakout visuals with broadcast-quality smoothness.', icon: '<polyline points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>' }
    ],
    benefits: [
      { stat: '100%', text: 'Brand-consistent visual environment across every session' },
      { stat: '3D', text: 'Immersive virtual environments replacing plain backgrounds' },
      { stat: 'Zero', text: 'Additional software needed for audience or speakers' },
      { stat: 'Live', text: 'Real-time scene transitions managed by our directors' },
      { stat: 'Multi', text: 'Platform support: Zoom, Teams, Webex, Meet' },
      { stat: 'HD', text: 'Broadcast-quality 1080p output maintained throughout' }
    ]
  },
  'hybrid-conference': {
    category: 'Virtual & Hybrid Events', eyebrow: 'In-Person + Remote',
    title: 'Hybrid Conference Solutions',
    desc: `A hybrid conference seamlessly connects an <strong>in-person audience</strong> at your venue with <strong>remote participants</strong> joining online — creating one unified, cohesive event experience. Our production team manages both the physical AV setup on-site and the digital streaming infrastructure to ensure every attendee feels equally engaged, regardless of where they are joining from.`,
    image: 'https://images.unsplash.com/photo-1591115765373-5207764f72e7?w=900&q=80',
    visualLabel: 'HYBRID EVENT PRODUCTION', visualSub: 'On-Site + Remote • Unified Experience',
    iconPath: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>',
    features: [
      { title: 'Venue AV Setup', desc: 'Professional cameras, microphones, and display systems installed at your physical venue to capture and present content with broadcast quality for both in-room and remote audiences.', icon: '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>' },
      { title: 'Remote Audience Integration', desc: 'Remote attendees join via their preferred platform (Zoom, Teams, Webex) and experience the same professional production quality as those physically present at the venue.', icon: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 010 20M12 2a15.3 15.3 0 000 20"/>' },
      { title: 'Interactive Q&A Bridging', desc: 'Our team manages Q&A across both audiences — routing questions from remote attendees to in-room moderators and vice versa, creating a truly interactive two-way event experience.', icon: '<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>' }
    ],
    benefits: [
      { stat: '2x', text: 'Audience reach vs purely in-person events' },
      { stat: 'Live', text: 'Simultaneous in-room and online participation' },
      { stat: 'HD', text: 'Broadcast-grade streams for remote attendees' },
      { stat: 'Zero', text: 'Lag or sync issues between in-person and remote' },
      { stat: 'Full', text: 'Q&A moderation across both audiences' },
      { stat: '24/7', text: 'Technical support from our dedicated event engineers' }
    ]
  },
  'town-halls-agms': {
    category: 'Virtual & Hybrid Events', eyebrow: 'Corporate Governance Events',
    title: 'Town Halls & AGMs',
    desc: `Town Halls and Annual General Meetings (AGMs) are among the most critical communications events an organisation holds. streamOrbits delivers these high-stakes events with <strong>broadcast-level production quality</strong> — ensuring your leadership communicates with authority, your shareholders receive clear information, and every participant feels the gravity and professionalism of the occasion.`,
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=900&q=80',
    visualLabel: 'ANNUAL GENERAL MEETING', visualSub: 'AGM Production • Global Broadcast',
    iconPath: '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 3H8l-4 4h16l-4-4z"/>',
    features: [
      { title: 'Executive Presentation Support', desc: 'Our production team works with your C-suite and board members ahead of the event, conducting tech checks, camera rehearsals, and slide synchronisation to ensure flawless on-screen performance.', icon: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>' },
      { title: 'Shareholder Broadcast', desc: 'Stream your AGM live to registered shareholders globally with secure access controls, branded viewing portals, and simultaneous multi-language support where required.', icon: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/>' },
      { title: 'Compliance Recording', desc: 'All sessions are professionally recorded in high resolution for compliance, archiving, and post-event distribution to stakeholders who could not attend live.', icon: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>' }
    ],
    benefits: [
      { stat: 'Secure', text: 'Authenticated shareholder access with branded portals' },
      { stat: 'Global', text: 'Broadcast to stakeholders across all time zones' },
      { stat: 'HD+', text: '4K recording for compliance archival' },
      { stat: 'Live', text: 'Real-time translation and captioning support' },
      { stat: 'Full', text: 'Executive pre-event rehearsal and tech checks' },
      { stat: '99.9%', text: 'Guaranteed uptime for critical governance events' }
    ]
  },
  'corporate-webinars': {
    category: 'Virtual & Hybrid Events', eyebrow: 'Knowledge & Training Events',
    title: 'Corporate Webinars',
    desc: `Corporate webinars are the most scalable format for <strong>training, product launches, thought leadership, and internal communications</strong>. streamOrbits transforms standard platform webinars into polished, professionally produced broadcasts — with branded visuals, seamless speaker management, and interactive audience engagement tools that keep participants attentive and involved.`,
    image: 'https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=900&q=80',
    visualLabel: 'CORPORATE WEBINAR', visualSub: 'Managed Production • Interactive',
    iconPath: '<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>',
    features: [
      { title: 'Speaker Management', desc: 'Complete speaker onboarding including pre-event briefings, camera position guidance, audio checks, and dry-run rehearsals. We ensure your presenters are confident and broadcast-ready before going live.', icon: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>' },
      { title: 'Branded Production', desc: 'Custom lower thirds, animated intro sequences, branded slide overlays, and sponsor recognition graphics are integrated live into the webinar stream by our vMix operators.', icon: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/>' },
      { title: 'Audience Engagement', desc: 'Live polling, Q&A moderation, chat management, and hand-raise features are actively managed by our team — maximising participant interaction and post-event data insights.', icon: '<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>' }
    ],
    benefits: [
      { stat: '1000+', text: 'Concurrent participants supported seamlessly' },
      { stat: 'Live', text: 'Active Q&A and polling management during event' },
      { stat: 'Brand', text: 'Full corporate branding integrated into every frame' },
      { stat: 'VOD', text: 'Recording delivered within hours post-event' },
      { stat: 'Data', text: 'Attendee engagement analytics and reporting' },
      { stat: 'Multi', text: 'Platform support: Zoom, Teams, ON24, Webex' }
    ]
  },
  'multi-platform-streaming': {
    category: 'Live Streaming/Webcast', eyebrow: 'Simultaneous Multi-Destination',
    title: 'Multi-Platform Streaming',
    desc: `Reach your entire audience wherever they are by streaming your live event <strong>simultaneously to multiple platforms</strong> — YouTube Live, LinkedIn Live, Facebook Live, your website, and any custom RTMP destination — all from a single production source. streamOrbits manages encoding, distribution, and monitoring across all channels in real time so you never miss a viewer.`,
    image: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=900&q=80',
    visualLabel: 'MULTI-PLATFORM STREAM', visualSub: 'YouTube • LinkedIn • Facebook • Custom',
    iconPath: '<path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 00-1.95 1.96A29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 001.95-1.95A29 29 0 0023 12a29 29 0 00-.46-5.58z"/>',
    features: [
      { title: 'Simultaneous Multi-Destination', desc: "A single production stream is encoded and distributed to all your chosen platforms simultaneously using professional streaming encoders — no quality loss, no delay difference between destinations.", icon: '<circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8 8 0 000 11.4M17.7 6.3a8 8 0 010 11.4"/>' },
      { title: 'Custom RTMP Destinations', desc: "Beyond mainstream social platforms, we can stream to any RTMP-compatible destination including your website's own video player, event registration platform, or private CDN endpoint.", icon: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>' },
      { title: 'Real-Time Monitoring', desc: 'Our technicians actively monitor all stream destinations throughout the event — checking bitrate, latency, and viewer counts across each platform and responding instantly to any technical issues.', icon: '<path d="M1 6l10.5 6L22 6M1 6v12l10.5 6L22 18V6"/>' }
    ],
    benefits: [
      { stat: '10+', text: 'Simultaneous platform destinations supported' },
      { stat: '4K', text: 'Source quality maintained across all streams' },
      { stat: 'Live', text: 'Real-time monitoring of all destinations' },
      { stat: 'Zero', text: 'Sync delay between platform destinations' },
      { stat: 'Custom', text: 'RTMP support for any private endpoint' },
      { stat: '24/7', text: 'Technical team monitoring your event live' }
    ]
  },
  'webcast-production': {
    category: 'Live Streaming/Webcast', eyebrow: 'Professional Broadcast Production',
    title: 'Webcast Production',
    desc: `A webcast is more than just a video call recorded and shared — it is a <strong>professionally produced live broadcast</strong> with structured visual storytelling, timed content delivery, and polished on-screen graphics. streamOrbits brings broadcast television production standards to your corporate webcast, creating an experience that commands attention and reinforces your brand credibility.`,
    image: 'https://images.unsplash.com/photo-1598387993281-cecf8b71a8f8?w=900&q=80',
    visualLabel: 'WEBCAST PRODUCTION', visualSub: 'Broadcast Grade • Corporate',
    iconPath: '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    features: [
      { title: 'Pre-Production Planning', desc: 'We work with your communications team to script the run-of-show, plan all visual elements, design lower thirds and graphics packages, and rehearse with speakers before going live.', icon: '<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/>' },
      { title: 'Live Direction', desc: 'An experienced live director manages the entire broadcast — calling camera cuts, triggering graphics, managing speaker transitions, and ensuring the visual narrative flows according to your programme.', icon: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>' },
      { title: 'Post-Production Delivery', desc: 'Following the live event, we deliver a professionally edited recording, chapter markers for VOD distribution, and highlight clips suitable for social media and internal communications.', icon: '<polygon points="5 3 19 12 5 21 5 3"/>' }
    ],
    benefits: [
      { stat: 'TV', text: 'Broadcast television production standards' },
      { stat: 'Full', text: 'Pre-production scripting and rehearsal support' },
      { stat: 'Live', text: 'Experienced director managing your entire broadcast' },
      { stat: 'HD', text: '1080p minimum output quality guaranteed' },
      { stat: 'VOD', text: 'Edited recording delivered post-event' },
      { stat: 'Brand', text: 'Complete custom graphics and lower thirds package' }
    ]
  },
  'cdn-delivery': {
    category: 'Live Streaming/Webcast', eyebrow: 'Global Content Distribution',
    title: 'CDN & Delivery',
    desc: `Content Delivery Networks (CDNs) ensure that your live stream reaches every viewer — whether they are in the same city as your studio or on the other side of the world — with <strong>minimal latency, consistent quality, and zero buffering</strong>. streamOrbits partners with enterprise CDN providers to guarantee flawless stream delivery to any audience size, anywhere on the planet.`,
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=900&q=80',
    visualLabel: 'CDN GLOBAL DELIVERY', visualSub: 'Low Latency • High Reliability',
    iconPath: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 010 20M12 2a15.3 15.3 0 000 20"/>',
    features: [
      { title: 'Enterprise CDN Partners', desc: 'We work with industry-leading CDN providers including Akamai, Cloudflare, and AWS CloudFront to ensure your stream benefits from global edge network infrastructure with 99.99% uptime SLAs.', icon: '<path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/>' },
      { title: 'Adaptive Bitrate Streaming', desc: "Our streams use adaptive bitrate (ABR) technology — automatically adjusting video quality in real time based on each viewer's available bandwidth, ensuring smooth playback on any connection speed.", icon: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>' },
      { title: 'Redundant Failover', desc: 'Primary and backup stream paths are configured in parallel. If the primary CDN path experiences any disruption, automatic failover switches your stream to the backup within seconds — invisible to viewers.', icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
    ],
    benefits: [
      { stat: '99.9%', text: 'Uptime SLA from our enterprise CDN partners' },
      { stat: 'Global', text: 'Edge nodes across 200+ countries and territories' },
      { stat: 'ABR', text: 'Adaptive bitrate for all connection speeds' },
      { stat: 'Auto', text: 'Failover switching in under 10 seconds' },
      { stat: 'Scale', text: 'From 100 to 100,000+ concurrent viewers' },
      { stat: 'Low', text: 'Sub-5 second latency for live events' }
    ]
  },
  'live-recording-vod': {
    category: 'Live Streaming/Webcast', eyebrow: 'Archive & On-Demand',
    title: 'Live Recording & VOD',
    desc: `Your live event does not end when the stream concludes. streamOrbits captures <strong>professional multi-source recordings</strong> of every event and delivers polished Video On Demand (VOD) assets that extend the reach and value of your content — allowing viewers who missed the live broadcast to experience the same quality production at their own convenience.`,
    image: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=900&q=80',
    visualLabel: 'RECORDING & VOD', visualSub: 'Multi-Source Archive • On-Demand',
    iconPath: '<circle cx="12" cy="12" r="10"/><polyline points="10 15 15 12 10 9 10 15"/>',
    features: [
      { title: 'Multi-Source Recording', desc: 'We record simultaneously from the production master, individual camera feeds, and screen capture sources — giving you complete flexibility in how the post-production edit is assembled.', icon: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>' },
      { title: 'Post-Event Editing', desc: 'Our editors produce a clean, chapter-marked VOD version of your event — removing technical holds, tightening transitions, and adding any post-produced graphics for a polished on-demand experience.', icon: '<polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/>' },
      { title: 'VOD Platform Delivery', desc: 'Finished recordings are delivered in formats optimised for your chosen platforms — whether that is your event registration portal, internal LMS, YouTube channel, or corporate intranet system.', icon: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/>' }
    ],
    benefits: [
      { stat: '4K', text: 'Master recording quality for archival' },
      { stat: 'Multi', text: 'Simultaneous recording of all source feeds' },
      { stat: '24hr', text: 'VOD delivery within 24 hours of event end' },
      { stat: 'Chap', text: 'Chapter markers for easy on-demand navigation' },
      { stat: 'Any', text: 'Delivery to any video platform or LMS' },
      { stat: 'Long', text: 'Long-term archive storage and management' }
    ]
  },
  'camera-studio-setup': {
    category: 'Production Services', eyebrow: 'Physical Production Infrastructure',
    title: 'Camera & Studio Setup',
    desc: `Professional on-camera presence starts with the right physical equipment. streamOrbits deploys <strong>broadcast-grade cameras, lighting rigs, and audio systems</strong> at your location — whether it is your corporate boardroom, conference venue, or dedicated broadcast studio — creating the physical foundation for a truly professional live production.`,
    gallery: [
      { src: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=900&q=80', label: 'Panasonic PMW300 — Studio Camera' },
      { src: 'https://images.unsplash.com/photo-1567593810070-7a3d471af022?w=900&q=80', label: 'PTZ Camera — Remote Head Setup' },
    ],
    visualLabel: 'STUDIO SETUP', visualSub: 'Broadcast Cameras • Lighting • Audio',
    iconPath: '<path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    features: [
      { title: 'PTZ & Broadcast Cameras', desc: 'We deploy professional PTZ (pan-tilt-zoom) cameras and traditional broadcast cameras, providing multiple angles and smooth automated movements controlled from our production desk.', icon: '<path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/>' },
      { title: 'Lighting Design', desc: 'Proper lighting is the single biggest upgrade to any video production. Our team designs and installs a three-point lighting setup ensuring your speakers look professional, well-lit, and broadcast-ready.', icon: '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>' },
      { title: 'Professional Audio', desc: 'Lapel microphones, boom mics, and audio mixers ensure pristine, clear audio capture from every speaker. Poor audio is the number one complaint in online events — we eliminate that risk entirely.', icon: '<path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z"/><path d="M19 10v2a7 7 0 01-14 0v-2"/>' }
    ],
    benefits: [
      { stat: '4K', text: 'Broadcast-grade 4K camera capability' },
      { stat: 'Multi', text: 'Multi-camera setups with up to 8 sources' },
      { stat: 'PTZ', text: 'Automated camera control from production desk' },
      { stat: 'Pro', text: 'Three-point professional lighting for all speakers' },
      { stat: 'Zero', text: 'Audio issues with professional lapel mic setup' },
      { stat: 'Full', text: 'Equipment transport, setup, and teardown managed' }
    ]
  },
  'vmix-switching': {
    category: 'Production Services', eyebrow: 'Real-Time Video Mixing',
    title: 'vMix Switching & Direction',
    desc: `vMix is the industry-leading professional live production software, and streamOrbits operates it at an expert level. Our <strong>vMix Technical Directors</strong> manage real-time switching between cameras, virtual sets, slides, pre-recorded video inserts, and graphics overlays — creating the seamless, dynamic visual experience your audience expects from a world-class live event.`,
    image: 'https://images.unsplash.com/photo-1601506521793-dc748fc80b67?w=900&q=80',
    visualLabel: 'vMix PRODUCTION', visualSub: 'Real-Time Switching • Live Direction',
    iconPath: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    features: [
      { title: 'Live Scene Switching', desc: 'Our vMix operators execute precise, timed cuts and transitions between all production sources — cameras, virtual sets, presenter slides, video playback, and remote speaker feeds — in real time throughout your event.', icon: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>' },
      { title: 'Lower Thirds & Overlays', desc: 'Speaker name cards, event titles, social media handles, sponsor logos, and countdown timers are triggered live by our operators — appearing and disappearing at precisely the right moments.', icon: '<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>' },
      { title: 'Instant Replay & Playback', desc: 'Pre-recorded video inserts, sponsor reels, and event bumpers are queued and triggered on cue — seamlessly inserted into the live programme without any visible joins or transitions.', icon: '<polygon points="5 3 19 12 5 21 5 3"/>' }
    ],
    benefits: [
      { stat: '60+', text: 'Available vMix input sources simultaneously' },
      { stat: 'Live', text: 'Frame-accurate switching and transitions' },
      { stat: 'Pro', text: 'Experienced Technical Directors on every event' },
      { stat: 'Zero', text: 'Visible joins between live and pre-recorded segments' },
      { stat: 'Custom', text: 'Full graphics package triggered live during event' },
      { stat: '4K', text: 'Ultra-HD output capability with vMix 4K' }
    ]
  },
  'graphics-lower-thirds': {
    category: 'Production Services', eyebrow: 'Custom Broadcast Graphics',
    title: 'Graphics & Lower Thirds',
    desc: `Professional broadcast graphics are the visual language of credibility. streamOrbits designs and produces <strong>custom animated graphics packages</strong> — from speaker lower thirds and event title cards to sponsor bumpers, countdown timers, and full-screen informational overlays — all triggered live during your event by our production team.`,
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=900&q=80',
    visualLabel: 'BROADCAST GRAPHICS', visualSub: 'Animated • Branded • Live',
    iconPath: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
    features: [
      { title: 'Animated Lower Thirds', desc: 'Custom-designed speaker identification graphics appear smoothly beneath each presenter — featuring their name, title, and organisation in your brand fonts, colours, and animation style.', icon: '<path d="M4 6h16M4 12h16M4 18h7"/>' },
      { title: 'Full-Screen Graphics', desc: 'Event title cards, section transitions, sponsor recognition screens, and informational overlays are designed and produced ahead of the event and triggered live at the appropriate moments.', icon: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/>' },
      { title: 'Branded Templates', desc: 'All graphics are built from your existing brand guidelines — using your approved colour palette, typography, logo treatments, and visual style to maintain complete brand consistency throughout the broadcast.', icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
    ],
    benefits: [
      { stat: '100%', text: 'Brand guideline compliance across all graphics' },
      { stat: 'Anim', text: 'Smooth animated entry and exit transitions' },
      { stat: 'Live', text: 'Real-time triggering by our production team' },
      { stat: 'Multi', text: 'Lower thirds, titles, sponsors, countdowns' },
      { stat: 'HD', text: '1080p vector-quality graphics rendering' },
      { stat: 'Fast', text: '48-hour graphics turnaround for urgent events' }
    ]
  },
  'virtual-sets-backgrounds': {
    category: 'Production Services', eyebrow: '3D Virtual Environments',
    title: 'Virtual Sets & Backgrounds',
    desc: `Virtual Sets and custom backgrounds replace the plain wall behind your speakers with a <strong>professionally designed 3D virtual environment</strong> — a branded corporate studio, a futuristic newsroom, a themed conference stage, or any custom environment matching your event identity. Using chroma key or AI-based removal, our team creates stunning virtual environments that make every speaker look like they are broadcasting from a world-class production facility.`,
    image: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=900&q=80',
    visualLabel: 'VIRTUAL ENVIRONMENT', visualSub: '3D Sets • AI Backgrounds • Live',
    iconPath: '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 3H8L4 7h16l-4-4z"/>',
    features: [
      { title: 'Custom 3D Set Design', desc: 'Our design team creates bespoke 3D virtual environments tailored to your event — complete with your branding, event theming, sponsor placements, and any visual elements required.', icon: '<path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>' },
      { title: 'AI Background Removal', desc: 'No green screen required. Our AI-powered background removal technology works with any standard webcam or camera setup, cleanly separating speakers from their physical environment and placing them in the virtual set.', icon: '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/>' },
      { title: 'Platform Integration', desc: 'Virtual sets are delivered directly into your online meeting platform — attendees in Zoom, Teams, or Webex see the fully rendered virtual environment without needing any special software or hardware.', icon: '<path d="M6.3 6.3a8 8 0 000 11.4M17.7 6.3a8 8 0 010 11.4"/><circle cx="12" cy="12" r="3"/>' }
    ],
    benefits: [
      { stat: '3D', text: 'Fully custom 3D rendered virtual environments' },
      { stat: 'AI', text: 'Green-screen free background removal technology' },
      { stat: 'Any', text: 'Works with standard webcam or broadcast camera' },
      { stat: 'Live', text: 'Real-time rendering during your event' },
      { stat: 'Brand', text: 'Complete brand integration within the virtual set' },
      { stat: 'Zoom', text: 'Compatible with Zoom, Teams, Webex, Meet' }
    ]
  },
  'zoom-events': {
    category: 'Platform Support', eyebrow: 'Zoom Platform Expertise',
    title: 'Zoom Events',
    desc: `Zoom is the world's most widely adopted video conferencing platform, and streamOrbits brings <strong>expert-level production management</strong> to every type of Zoom event — from intimate team meetings to large-scale Zoom Webinars and Zoom Events with thousands of attendees. We manage every technical aspect so your team can focus entirely on the content.`,
    image: 'https://images.unsplash.com/photo-1609921212029-bb5a28e60960?w=900&q=80',
    visualLabel: 'ZOOM EVENTS', visualSub: 'Webinar • Conference • Town Hall',
    iconPath: '<path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    features: [
      { title: 'Zoom Webinar Management', desc: 'Full Zoom Webinar setup including registration pages, attendee management, panelist onboarding, Q&A moderation, polling, and post-event reporting — all managed by our dedicated event team.', icon: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>' },
      { title: 'vMix + Zoom Integration', desc: 'We connect our vMix production environment directly to Zoom using NDI or virtual camera technology — feeding broadcast-quality video with lower thirds, virtual sets, and multi-camera switching directly into your Zoom session.', icon: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' },
      { title: 'Technical Support', desc: 'Our Zoom-certified technicians provide live technical support throughout your event — managing participant permissions, troubleshooting audio/video issues, and ensuring the event runs without interruption.', icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
    ],
    benefits: [
      { stat: 'Cert', text: 'Zoom-certified event technicians on every event' },
      { stat: '1000+', text: 'Attendee capacity managed seamlessly' },
      { stat: 'Live', text: 'vMix integration for broadcast-quality output' },
      { stat: 'Full', text: 'Registration, onboarding, and Q&A managed' },
      { stat: 'Zero', text: 'Technical disruptions with our active support' },
      { stat: 'Post', text: 'Attendee analytics and recording delivered' }
    ]
  },
  'microsoft-teams': {
    category: 'Platform Support', eyebrow: 'Microsoft Teams Production',
    title: 'Microsoft Teams',
    desc: `Microsoft Teams is the enterprise communication backbone for millions of organisations worldwide. streamOrbits delivers <strong>professional production management for Teams Live Events and Webinars</strong> — transforming standard Teams meetings into polished, broadcast-quality corporate communications with full vMix integration and expert technical direction.`,
    image: 'https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?w=900&q=80',
    visualLabel: 'MICROSOFT TEAMS', visualSub: 'Live Events • Webinars • Town Halls',
    iconPath: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
    features: [
      { title: 'Teams Live Events', desc: 'We produce and manage Microsoft Teams Live Events — handling presenter onboarding, Q&A moderation, technical direction, and post-event recording delivery for audiences of any size within your organisation.', icon: '<path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/>' },
      { title: 'External Broadcasting', desc: 'Using RTMP injection, we connect our vMix production directly to Teams — feeding custom graphics, virtual sets, and multi-camera production into your Teams session for a broadcast experience your attendees will remember.', icon: '<circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8 8 0 000 11.4M17.7 6.3a8 8 0 010 11.4"/>' },
      { title: 'IT Coordination', desc: 'Our team works directly with your IT department to ensure network configurations, firewall rules, and Teams admin policies are correctly set for large-scale live events without disrupting your existing infrastructure.', icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
    ],
    benefits: [
      { stat: 'MS', text: 'Microsoft Teams certified production partner' },
      { stat: 'RTMP', text: 'External production injection via RTMP' },
      { stat: '10K+', text: 'Attendee capacity for Teams Live Events' },
      { stat: 'IT', text: 'Full coordination with your IT and admin team' },
      { stat: 'Live', text: 'Custom vMix graphics fed into Teams session' },
      { stat: 'Record', text: 'Automatic Teams recording plus production archive' }
    ]
  },
  'cisco-webex': {
    category: 'Platform Support', eyebrow: 'Webex Platform Production',
    title: 'Cisco Webex',
    desc: `Cisco Webex is the preferred platform for many enterprise and government organisations that require the highest levels of <strong>security, compliance, and reliability</strong>. streamOrbits brings expert Webex production management and vMix integration — delivering broadcast-quality events within the Webex environment without compromising on security or compliance requirements.`,
    image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=900&q=80',
    visualLabel: 'CISCO WEBEX', visualSub: 'Enterprise • Secure • Compliant',
    iconPath: '<path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/>',
    features: [
      { title: 'Webex Events Management', desc: 'Complete Webex Events production — registration setup, host management, panelist briefing, attendee Q&A, polling, and recording — managed end-to-end by our dedicated Webex event specialists.', icon: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>' },
      { title: 'Hardware Bridge Integration', desc: 'streamOrbits has deep expertise with Cisco hardware VC bridges (Cisco Room Kits, Webex Boards) — integrating physical room systems into Webex events for true hybrid conference experiences.', icon: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/>' },
      { title: 'Security & Compliance', desc: "All our Webex productions maintain full compliance with your organisation's security policies — including encrypted streams, authenticated participant access, and data residency requirements where applicable.", icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
    ],
    benefits: [
      { stat: 'Cert', text: 'Cisco Webex certified production partner' },
      { stat: 'Sec', text: 'Enterprise security and compliance maintained' },
      { stat: 'HW', text: 'Cisco hardware room system integration' },
      { stat: 'E2E', text: 'End-to-end encrypted event streams' },
      { stat: 'Govt', text: 'Government-grade compliance support' },
      { stat: 'Full', text: 'Webex Events full lifecycle management' }
    ]
  },
  'google-meet-on24': {
    category: 'Platform Support', eyebrow: 'Google Meet & ON24 Production',
    title: 'Google Meet & ON24',
    desc: `streamOrbits provides expert production management for both <strong>Google Meet</strong> — ideal for Google Workspace organisations — and <strong>ON24</strong>, the leading dedicated webinar and virtual event platform used by global enterprises for demand generation and audience engagement events.`,
    visualLabel: 'GOOGLE MEET & ON24', visualSub: 'Meet • ON24 Webinars • Virtual Events',
    iconPath: '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>',
    features: [
      { title: 'Google Meet Production', desc: 'We integrate vMix with Google Meet using virtual camera technology — feeding broadcast-quality multi-camera production, branded graphics, and virtual sets directly into your Google Meet session for a premium experience.', icon: '<path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/>' },
      { title: 'ON24 Webinar Platform', desc: 'ON24 is built specifically for large-scale B2B webinars and virtual events. Our team manages the full ON24 event lifecycle — from console setup and speaker integration to live technical direction and post-event analytics review.', icon: '<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>' },
      { title: 'Audience Engagement Tools', desc: "ON24's built-in engagement tools — live Q&A, polling, resource downloads, CTAs, and audience response features — are actively managed by our team, maximising participant interaction and lead generation outcomes.", icon: '<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>' }
    ],
    benefits: [
      { stat: 'GWS', text: 'Deep Google Workspace ecosystem integration' },
      { stat: 'ON24', text: 'Certified ON24 platform production partner' },
      { stat: 'Live', text: 'vMix integration via virtual camera technology' },
      { stat: 'Data', text: 'ON24 audience engagement analytics delivered' },
      { stat: 'Scale', text: 'Thousands of concurrent ON24 attendees managed' },
      { stat: 'Full', text: 'End-to-end event lifecycle management' }
    ]
  }
};

export default serviceData;
