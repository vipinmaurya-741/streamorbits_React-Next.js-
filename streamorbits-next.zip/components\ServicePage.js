'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';

export default function ServicePage({ data, onOpenContact }) {
  const [galleryIdx, setGalleryIdx] = useState(0);
  const galleryTimer = useRef(null);

  useEffect(() => {
    if (data.gallery && data.gallery.length > 1) {
      galleryTimer.current = setInterval(() => {
        setGalleryIdx(i => (i + 1) % data.gallery.length);
      }, 3500);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return () => clearInterval(galleryTimer.current);
  }, [data]);

  const hasPhoto = data.image || data.gallery;

  return (
    <>
      <section className="sp-hero">
        <div className="sp-hero__inner">
          <div>
            <div className="sp-breadcrumb">
              <Link href="/">Home</Link>
              <span className="sep">›</span>
              <a href="#">{data.category}</a>
              <span className="sep">›</span>
              <span className="cur">{data.title}</span>
            </div>
            <div className="sp-eyebrow">{data.eyebrow}</div>
            <h1 className="sp-title">{data.title}</h1>
            <div className="sp-title-bar"></div>
            <p className="sp-desc" dangerouslySetInnerHTML={{__html: data.desc}}/>
            <div style={{display:'flex',gap:'12px',flexWrap:'wrap',alignItems:'center'}}>
              <Link href="/" className="btn-primary" style={{textDecoration:'none'}}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                Back to Home
              </Link>
              <button className="btn-outline" onClick={onOpenContact} style={{cursor:'pointer'}}>Get a Quote</button>
            </div>
          </div>

          <div className={`sp-visual${hasPhoto ? ' sp-visual--photo' : ''}`}>
            <div className="sp-visual__badge"><span className="sp-visual__dot"></span>LIVE</div>
            {data.gallery ? (
              <div className="sp-gallery">
                {data.gallery.map((g, i) => (
                  <div key={i} className={`sp-gallery__slide${galleryIdx === i ? ' active' : ''}`}>
                    <img src={g.src} alt={g.label} className="sp-visual__photo"/>
                    <div className="sp-visual__photo-caption">
                      <div className="sp-visual__label">{g.label}</div>
                      <div className="sp-visual__sub">{data.visualSub}</div>
                    </div>
                  </div>
                ))}
                <div className="sp-gallery__dots">
                  {data.gallery.map((_, i) => (
                    <button key={i} className={`sp-gallery__dot${galleryIdx === i ? ' active' : ''}`} onClick={() => { setGalleryIdx(i); clearInterval(galleryTimer.current); }}></button>
                  ))}
                </div>
                <button className="sp-gallery__prev" onClick={() => { setGalleryIdx(i => (i - 1 + data.gallery.length) % data.gallery.length); clearInterval(galleryTimer.current); }}>&#8249;</button>
                <button className="sp-gallery__next" onClick={() => { setGalleryIdx(i => (i + 1) % data.gallery.length); clearInterval(galleryTimer.current); }}>&#8250;</button>
              </div>
            ) : data.image ? (
              <>
                <img src={data.image} alt={data.title} className="sp-visual__photo"/>
                <div className="sp-visual__photo-caption">
                  <div className="sp-visual__label">{data.visualLabel}</div>
                  <div className="sp-visual__sub">{data.visualSub}</div>
                </div>
              </>
            ) : (
              <>
                <div className="sp-visual__icon">
                  <svg viewBox="0 0 24 24" dangerouslySetInnerHTML={{__html: data.iconPath}}/>
                </div>
                <div className="sp-visual__label">{data.visualLabel}</div>
                <div className="sp-visual__sub">{data.visualSub}</div>
              </>
            )}
          </div>
        </div>
      </section>

      <section className="sp-features">
        <div className="sp-features__inner">
          <div className="sp-features__header">
            <div className="section-label">What We Offer</div>
            <h2 className="section-title">Key Features <span className="red-dash"></span></h2>
          </div>
          <div className="sp-features__grid">
            {data.features.map((f, i) => (
              <div key={i} className="sp-feat-card">
                <div className="sp-feat-card__icon">
                  <svg viewBox="0 0 24 24" dangerouslySetInnerHTML={{__html: f.icon}}/>
                </div>
                <div className="sp-feat-card__title">{f.title}</div>
                <div className="sp-feat-card__desc">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="sp-benefits">
        <div className="sp-benefits__inner">
          <div className="sp-benefits__header">
            <div className="section-label" style={{justifyContent:'center'}}>Why It Matters</div>
            <h2 className="section-title centered">Key Benefits <span className="red-dash"></span></h2>
          </div>
          <div className="sp-benefits__grid">
            {data.benefits.map((b, i) => (
              <div key={i} className="sp-ben-card">
                <div className="sp-ben-card__num">{b.stat}</div>
                <div className="sp-ben-card__text">{b.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="cta-band">
        <div className="container">
          <h2 className="cta-band__title">Ready to Elevate Your Next Event?</h2>
          <p className="cta-band__sub">Talk to our team about your {data.title} requirements today.</p>
          <button className="btn-white" onClick={onOpenContact}>Contact Our Team</button>
        </div>
      </div>
    </>
  );
}
