'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const navItems = [
  {
    label: 'Virtual & Hybrid Events',
    items: [
      { label: 'Virtual Set Events', slug: 'virtual-set-events' },
      { label: 'Hybrid Conference Solutions', slug: 'hybrid-conference' },
      { label: 'Town Halls & AGMs', slug: 'town-halls-agms' },
      { label: 'Corporate Webinars', slug: 'corporate-webinars' },
    ]
  },
  {
    label: 'Live Streaming/Webcast',
    items: [
      { label: 'Multi-Platform Streaming', slug: 'multi-platform-streaming' },
      { label: 'Webcast Production', slug: 'webcast-production' },
      { label: 'CDN & Delivery', slug: 'cdn-delivery' },
      { label: 'Live Recording & VOD', slug: 'live-recording-vod' },
    ]
  },
  {
    label: 'Production Services',
    items: [
      { label: 'Camera & Studio Setup', slug: 'camera-studio-setup' },
      { label: 'vMix Switching & Direction', slug: 'vmix-switching' },
      { label: 'Graphics & Lower Thirds', slug: 'graphics-lower-thirds' },
      { label: 'Virtual Sets & Backgrounds', slug: 'virtual-sets-backgrounds' },
    ]
  },
  {
    label: 'Platform Support',
    items: [
      { label: 'Zoom Events', slug: 'zoom-events' },
      { label: 'Microsoft Teams', slug: 'microsoft-teams' },
      { label: 'Cisco Webex', slug: 'cisco-webex' },
      { label: 'Google Meet & ON24', slug: 'google-meet-on24' },
    ]
  },
];

export default function Navbar({ onOpenContact }) {
  const [scrolled, setScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleClick = (e) => {
      if (!e.target.closest('[data-dropdown-item]')) {
        setActiveDropdown(null);
      }
    };
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  const toggleDropdown = (idx) => {
    setActiveDropdown(activeDropdown === idx ? null : idx);
  };

  return (
    <nav className={`navbar${scrolled ? ' scrolled' : ''}`} id="navbar">
      <div className="navbar__inner">
        <Link href="/" className="logo">
          <svg className="logo__svg" viewBox="0 0 320 80" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M18 52 C30 10, 90 2, 115 18" stroke="#2BBCBE" strokeWidth="3.5" strokeLinecap="round" fill="none"/>
            <path d="M115 18 C140 35, 95 68, 55 72 C35 74, 18 65, 18 52" stroke="#2BBCBE" strokeWidth="3.5" strokeLinecap="round" fill="none"/>
            <path d="M22 30 C50 15, 90 14, 112 28" stroke="#2BBCBE" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.55"/>
            <circle cx="115" cy="16" r="3.5" fill="#2BBCBE"/>
            <circle cx="120" cy="10" r="2.2" fill="#2BBCBE" opacity="0.7"/>
            <circle cx="126" cy="6" r="1.4" fill="#2BBCBE" opacity="0.45"/>
            <circle cx="18" cy="54" r="4.5" fill="#2BBCBE"/>
            <circle cx="13" cy="62" r="2.8" fill="#2BBCBE" opacity="0.65"/>
            <circle cx="9" cy="70" r="1.6" fill="#2BBCBE" opacity="0.4"/>
            <text x="138" y="42" fontFamily="Barlow Condensed,Arial,sans-serif" fontSize="16" fontWeight="600" fill="#0B2259" letterSpacing="1">stream</text>
            <text x="138" y="66" fontFamily="Barlow Condensed,Arial,sans-serif" fontSize="30" fontWeight="800" fill="#2BBCBE" letterSpacing="1.5">ORBITS</text>
          </svg>
        </Link>

        <ul className={`nav-menu${menuOpen ? ' open' : ''}`} id="navMenu">
          {navItems.map((group, idx) => (
            <li key={idx} className={`nav-item${activeDropdown === idx ? ' active' : ''}`} data-dropdown-item>
              <button className="nav-link" onClick={(e) => { e.stopPropagation(); toggleDropdown(idx); }}>
                {group.label}
                <svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>
              </button>
              <div className="dropdown">
                {group.items.map((item) => (
                  <Link key={item.slug} href={`/services/${item.slug}`} onClick={() => { setActiveDropdown(null); setMenuOpen(false); }}>
                    {item.label}
                  </Link>
                ))}
              </div>
            </li>
          ))}
          <li className="nav-item">
            <button className="nav-link nav-cta" onClick={() => { onOpenContact(); setMenuOpen(false); }}>
              Get a Quote
            </button>
          </li>
        </ul>

        <button className="hamburger" id="hamburger" aria-label="Toggle menu" onClick={() => setMenuOpen(!menuOpen)}>
          <span></span><span></span><span></span>
        </button>
      </div>
    </nav>
  );
}
